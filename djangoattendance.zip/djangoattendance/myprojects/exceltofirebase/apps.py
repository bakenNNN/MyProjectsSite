from django.apps import AppConfig


class ExceltofirebaseConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'myprojects.exceltofirebase'
