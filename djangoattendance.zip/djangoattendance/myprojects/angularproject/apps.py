from django.apps import AppConfig


class AngularprojectConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'myprojects.angularproject'
