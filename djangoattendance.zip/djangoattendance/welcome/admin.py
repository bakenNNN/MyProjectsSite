from django.contrib import admin
from .models import WelcomeText
admin.site.register(WelcomeText)
# Register your models here.
